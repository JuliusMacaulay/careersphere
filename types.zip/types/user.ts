export interface IUser {
    imageUrl: any
    userId: string
    userImage: string
    firstname: string
    lastname?: string
}